document.getElementById("action").addEventListener("click", function(){
    var myArray = new Array();
	myArray[0] = "1. Mow lawn";
    myArray[1] = "2. Cook dinner";
    myArray[2] = "3. Wash dishes";
    myArray[3] = "4";
    var s = "";
          s += "<br>" + myArray[0] +"</br>";
          s += "<br>" + myArray[1] +"</br>";
          s += "<br>" + myArray[2] +"</br>";
          s += "<br>" + myArray[3] +"</br>";
    document.getElementById("todo-list").innerHTML = s;
    myArray.push(prompt("Your to do list current contains these item:\n1. Mow lawn\n2. Cook dinner\n3. Wash dishes\n-----------------------\nPlease enter another item."));

});