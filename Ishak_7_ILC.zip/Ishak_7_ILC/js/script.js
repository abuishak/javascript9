
function UnitConvertor(unitsInInches) {
    this.unitsInInches = unitsInInches;
}
UnitConvertor.prototype.getMeters = function () {
    var meters = this.unitsInInches / 39.370;
    return meters;
}
UnitConvertor.prototype.getCentimeters = function () {
    return this.unitsInInches / 0.39370;
}
UnitConvertor.prototype.getMillimeters = function () {
    return this.unitsInInches / 0.039370;
}
UnitConvertor.prototype.getFeet = function () {
    return this.unitsInInches / 0.0833;
}
UnitConvertor.prototype.getInches = function () {
    return this.unitsInInches;
}

var units = [];
document.getElementById("action").addEventListener("click", function(){
   var sentinel = "Q";
   var promptText = "Please enter a unit in inches.";
   promptText += "Enter'" + sentinel.toUpperCase() + "'to stop entry.";
   var a = prompt(promptText, "");
   while(a != sentinel.toLowerCase() && a != sentinel.toUpperCase()){
    var err ="";
    if(!isNaN(a)){
      a = parseFloat(a);
      var u = new UnitConvertor(a);
      units.push(u);  
    } else {
        err.message = "Error! you must only enter a number!\n\n";
    }
    a = prompt(err + promptText, "");
   } 
   var s = "Outputting entries...<br/>";
       s += "<br />";
   for(var i = 0; i <units.length;i++){
       s += "Entry #" + (i + 1) + "<br />";
       s += units[i].getInches().toFixed(2) + "converts as follows: <br />";
       s += "<ul>";
        s += "<li>Meters: " + units[i].getMeters().toFixed(2) + "</li>";
        s += "<li>Meters: " + units[i].getCentimeters().toFixed(2) + "</li>";
        s += "<li>Meters: " + units[i].getMillimeters().toFixed(2) + "</li>";
        s += "<li>Meters: " + units[i].getFeet().toFixed(2) + "</li>";
       s +="</ul>";
       
       if(i != units.length -1) {
           s +="<hr />";
       }
       document.getElementById("result").innerHTML = s;
   }
});