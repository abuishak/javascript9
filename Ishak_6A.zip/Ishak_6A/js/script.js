document.getElementById("action").addEventListener("click", function(){
    var myArray = new Array();
        myArray [0] = "";
        var s = "Please add an item to the to list";
        var input = prompt("Please add an item to the to list");
    var fValues =[];
    while(input != 'q' && input != 'q' ) {
        if(isNaN(input)) {
         var m = "<h2>Error!</h2>"
             m +="Error ! Plaese only enter number!\n"+s;
            input = prompt(s,0);
        } else {
            fValues.push(input);
            input = prompt(s,0);
        }
        
    }
    writeItems(fValues);
    
});
function getItems(fItems) {
    var items = "";
    return items;
}
function writeItems(aItems) {
    var s = ("");
            s += '<ul>'
        for(var i = 0; i <aItems.length; i++) {
            s+='<li>'
        s += aItems[i]++;
        s += getItems(aItems[i]);
        s+='</li>'
        }
        s += '</ul>'
        document.getElementById("todo-list").innerHTML = s;
}

  