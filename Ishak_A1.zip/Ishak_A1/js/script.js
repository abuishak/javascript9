//document.write("<h1> My First Script!</h1>);
//document.write("<p style='color:blue;'>Hello, world, My name is Abu Ishak.</p>");
//document.write("<p>I am a student at Mettrolitan College in Omaha Nebraska!</p>");

